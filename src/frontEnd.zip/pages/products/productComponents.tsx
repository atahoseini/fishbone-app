import React, { useState } from "react";
import { Button, Modal } from "react-bootstrap";
import "../../App.css";
import ProductList from "./productList";
import AddProduct from "./addProduct";

const ProductComponents = () => {
	const [showModal, setShowModal] = useState(false);


	return (
		<>
			<div>
				<Button variant="success" onClick={()=> setShowModal(true)}>Add New Product</Button>
			</div>
			<div>
				<ProductList />
			</div>
			<Modal show={showModal} onHide={() => setShowModal(false)}>
				<Modal.Header closeButton>
					<Modal.Title>Add Product</Modal.Title>
				</Modal.Header>
				<Modal.Body>
					<AddProduct onClose={() => setShowModal(false)} />
				</Modal.Body>
			</Modal>
		</>
	);
};

export default ProductComponents;
