import React, { useState, useEffect } from "react";
import axios from "axios";
import { Modal, Button, Form, Toast } from "react-bootstrap";

interface User {
  id: string;
  userName: string;
  firstName: string;
  lastName: string;
}

interface Product {
  id: number;
  productName: string;
  productPrice: number;
  productStock: number;
}

interface Order {
  id: number;
  userId: string;
  user: {
    id: number;
    userName: string;
    firstName: string;
    lastName: string;
  };
  orderDate: string;
  productId: number;
  product: {
    id: number;
    productName: string;
    productPrice: number;
    productStock: number;
    productDescription: string;
  };
  orderQuantity: number;
  orderTotal: number;
  description: string | null;
}

interface UpdateOrderModalProps {
  order: Order | undefined;
  closeModal: () => void;
  onOrderUpdated: () => void;
}

const UpdateOrderModal = ({ order, closeModal, onOrderUpdated }: UpdateOrderModalProps) => {
  const [users, setUsers] = useState<User[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [selectedUserId, setSelectedUserId] = useState<string>("");
  const [selectedProductId, setSelectedProductId] = useState<number>(0);
  const [orderDate, setOrderDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [description, setDescription] = useState<string>("");
  const [quantity, setQuantity] = useState<number>(1);
  const [orderTotal, setOrderTotal] = useState<number>(0);
  const [showToast, setShowToast] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  useEffect(() => {
    axios.get("http://localhost:5293/User/loadUsers")
      .then((response) => {
        setUsers(response.data);
      })
      .catch((error) => {
        console.error("Error fetching users:", error);
      });

    axios.get("http://localhost:5293/Product")
      .then((response) => {
        setProducts(response.data);
      })
      .catch((error) => {
        console.error("Error fetching products:", error);
      });
  }, []);

  useEffect(() => {
    if (order) {
      setSelectedUserId(order.userId);
      setSelectedProductId(order.productId);
      setOrderDate(order.orderDate);
      setQuantity(order.orderQuantity);
      setDescription(order.description || "");
      setOrderTotal(order.orderTotal);
    }
  }, [order]);

  useEffect(() => {
    const selectedProduct = products.find(product => product.id === selectedProductId);
    if (selectedProduct) {
      const total = quantity * selectedProduct.productPrice;
      const totalWithVAT = total * 1.20;  // فرضی VAT 20%
      setOrderTotal(totalWithVAT);
    }
  }, [quantity, selectedProductId, products]);

  const handleUpdateOrder = (e: React.FormEvent) => {
    e.preventDefault();

    const selectedProduct = products.find(product => product.id === selectedProductId);
    if (!selectedProduct) return;

    if (quantity > selectedProduct.productStock) {
      setMessage("Quantity exceeds available stock.");
      setShowToast(true);
      return;
    }

    if (quantity <= 0) {
      setMessage("Quantity must be greater than zero.");
      setShowToast(true);
      return;
    }

    const updatedOrder = {
      id: order!.id,
      userId: selectedUserId,
      orderDate,
      productId: selectedProductId,
      quantity,
      orderTotal,
      description,
    };

    axios
      .post("http://localhost:5293/Order/edit", updatedOrder)
      .then((response) => {
        console.log("Order updated successfully:", response.data);
        setMessage("Order updated successfully");
        setShowToast(true);
        onOrderUpdated();
        closeModal();

        // Update product stock
        const updatedProduct = { ...selectedProduct, productStock: selectedProduct.productStock - quantity };
        axios
          .put(`http://localhost:5293/Product/edit`, updatedProduct)
          .then((response) => {
            console.log("Product stock updated:", response.data);
          })
          .catch((error) => {
            console.error("Error updating product stock:", error);
          });
      })
      .catch((error) => {
        console.error("Error updating order:", error);
        setMessage("Error updating order");
        setShowToast(true);
      });
  };

  const handleCloseToast = () => {
    setShowToast(false);
  };

  return (
    <Modal show={true} onHide={closeModal}>
      <Modal.Header closeButton>
        <Modal.Title>Update Order</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Form onSubmit={handleUpdateOrder}>
          <Toast show={showToast} onClose={handleCloseToast} delay={5000} autohide>
            <Toast.Header>
              <strong className="me-auto">Order Status</strong>
            </Toast.Header>
            <Toast.Body>{message}</Toast.Body>
          </Toast>
          <div className="mb-3">
            <Form.Group controlId="formUser">
              <Form.Label>User</Form.Label>
              <Form.Control
                as="select"
                value={selectedUserId}
                onChange={(e) => setSelectedUserId(e.target.value)}
              >
                {users.map((user) => (
                  <option key={user.id} value={user.id}>
                    {user.userName}
                  </option>
                ))}
              </Form.Control>
            </Form.Group>
          </div>
          <div className="mb-3">
            <Form.Group controlId="formProduct">
              <Form.Label>Product</Form.Label>
              <Form.Control
                as="select"
                value={selectedProductId}
                onChange={(e) => setSelectedProductId(Number(e.target.value))}
              >
                {products.map((product) => (
                  <option key={product.id} value={product.id}>
                    {product.productName}
                  </option>
                ))}
              </Form.Control>
            </Form.Group>
          </div>
          <div className="mb-3">
            <Form.Group controlId="formQuantity">
              <Form.Label>Quantity</Form.Label>
              <Form.Control
                type="number"
                value={quantity}
                onChange={(e) => setQuantity(Number(e.target.value))}
                min="1"
              />
            </Form.Group>
          </div>
          <div className="mb-3">
            <Form.Group controlId="formDescription">
              <Form.Label>Description</Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
              />
            </Form.Group>
          </div>
          <div className="mb-3">
            <Form.Group controlId="formTotal">
              <Form.Label>Total with VAT</Form.Label>
              <Form.Control type="text" value={orderTotal.toFixed(2)} readOnly />
            </Form.Group>
          </div>
          <Modal.Footer>
            <Button variant="secondary" onClick={closeModal}>
              Cancel
            </Button>
            <Button variant="primary" type="submit">
              Update Order
            </Button>
          </Modal.Footer>
        </Form>
      </Modal.Body>
    </Modal>
  );
};

export default UpdateOrderModal;
