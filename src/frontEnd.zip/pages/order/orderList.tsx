import React, { useEffect, useState } from "react";
import axios from "axios";
import UpdateOrderModal from "./updateOrder";
import DeleteOrderConfirmation from "./deleteOrder";
import Pagination from "../users/paginationProps";
import { Button, Table } from "react-bootstrap";

interface Order {
  id: number;
  userId: string;
  user: {
    id: number;
    userName: string;
    firstName: string;
    lastName: string;
  };
  orderDate: string;
  productId: number;
  product: {
    id: number;
    productName: string;
    productPrice: number;
    productStock: number;
    productDescription: string;
  };
  orderQuantity: number;
  orderTotal: number;
  description: string | null;
}

interface OrderListProps {
  refreshList: boolean;  
}

const OrderList = ({ refreshList }: OrderListProps) => {
  const pageSize = 5;
  const [page, setPage] = useState<number>(1);
  const [pageCount, setPageCount] = useState<number>(1);
  const [orders, setOrders] = useState<Order[]>([]);
  const [selectedOrderId, setSelectedOrderId] = useState<number | null>(null);
  const [showUpdateModal, setShowUpdateModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [showDetails, setShowDetails] = useState<{ [key: number]: boolean }>({});

  useEffect(() => {
    axios.get(`http://localhost:5293/Order?page=${page}&size=${pageSize}`)
      .then((response) => {
        const fetchedOrders = response.data.data;
        setOrders(fetchedOrders);
        setPageCount(response.data.pageCount);
      })
      .catch((error) => {
        console.error("Error fetching orders:", error);
      });
  }, [page, refreshList]);

  const handlePageChange = (newPage: number) => {
    setPage(newPage);
  };

  const handleUpdateClick = (orderId: number) => {
    setSelectedOrderId(orderId);
    setShowUpdateModal(true);
  };

  const handleDeleteClick = (orderId: number) => {
    setSelectedOrderId(orderId);
    setShowDeleteModal(true);
  };

  const handleUpdateModalClose = () => {
    setSelectedOrderId(null);
    setShowUpdateModal(false);
  };

  const handleDeleteModalClose = () => {
    setSelectedOrderId(null);
    setShowDeleteModal(false);
  };

  const toggleDetails = (orderId: number) => {
    setShowDetails((prev) => ({ ...prev, [orderId]: !prev[orderId] }));
  };

  return (
    <div>
      <div>
        <h1 className="text-center">All Orders</h1>
        <Table striped bordered hover className="mx-auto" style={{ width: "70%" }}>
          <thead>
            <tr>
              <th>Order ID</th>
              <th>User Name</th>
              <th>Product</th>
              <th>Quantity</th>
              <th>Total Price</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {orders.map((order) => (
              <React.Fragment key={order.id}>
                <tr>
                  <td>{order.id}</td>
                  <td>{order.user.userName}</td>
                  <td>{order.product.productName}</td>
                  <td>{order.orderQuantity}</td>
                  <td>{order.orderTotal.toFixed(2)}</td>
                  <td>
                    <Button className="m-1" variant="warning" onClick={() => handleUpdateClick(order.id)}>Edit</Button>
                    <Button className="m-1" variant="danger" onClick={() => handleDeleteClick(order.id)}>Delete</Button>
                    <Button className="m-1" variant="info" onClick={() => toggleDetails(order.id)}>
                      {showDetails[order.id] ? "Hide" : "Show"} Details
                    </Button>
                  </td>
                </tr>
                {showDetails[order.id] && (
                  <tr>
                    <td colSpan={6}>
                      <div>
                        <strong>Product Description:</strong> {order.product.productDescription}
                      </div>
                      <div>
                        <strong>Order Date:</strong> {order.orderDate}
                      </div>
                      <div>
                        <strong>Description:</strong> {order.description}
                      </div>
                    </td>
                  </tr>
                )}
              </React.Fragment>
            ))}
          </tbody>
        </Table>
      </div>
      <div className="d-flex justify-content-center align-items-center">
        <Pagination total={pageSize * pageCount} page={page} pageCount={pageCount} size={pageSize} onPageChange={handlePageChange} />
      </div>
      {showUpdateModal && (
        <UpdateOrderModal 
          order={orders.find(order => order.id === selectedOrderId)} 
          closeModal={handleUpdateModalClose} 
          onOrderUpdated={() => setPage(page)} 
        />
      )}
      {showDeleteModal && selectedOrderId !== null && (
        <DeleteOrderConfirmation 
          orderId={selectedOrderId} 
          productId={orders.find(order => order.id === selectedOrderId)!.productId} 
          quantity={orders.find(order => order.id === selectedOrderId)!.orderQuantity} 
          closeModal={handleDeleteModalClose} 
        />
      )}
    </div>
  );
};

export default OrderList;
