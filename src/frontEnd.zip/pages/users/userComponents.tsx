
import React, { useState } from "react";
import { Button, Modal } from "react-bootstrap";
import "../../App.css";
import UserList from "./userList";
import AddUser from "./addUser";


const UserComponnets = () => {
    const [showModal, setShowModal] = useState(false);

    return (
        <>
            <div>
                <Button variant="success" onClick={() => setShowModal(true)}>Add New User</Button>
            </div>
            <div>
                <UserList />
            </div>
            <Modal show={showModal} onHide={() => setShowModal(false)}>
                <Modal.Header closeButton>
                    <Modal.Title>Add User</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <AddUser onClose={() => setShowModal(false)} />
                </Modal.Body>
            </Modal>
        </>
    );
};

export default UserComponnets;


