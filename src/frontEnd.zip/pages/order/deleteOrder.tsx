import React from "react";
import { Modal, Button } from "react-bootstrap";
import axios from "axios";

interface DeleteOrderConfirmationProps {
  orderId: number;
  productId: number;
  quantity: number;
  closeModal: () => void;
}

const DeleteOrderConfirmation: React.FC<DeleteOrderConfirmationProps> = ({ orderId, productId, quantity, closeModal }) => {
  const handleDeleteOrder = () => {
    console.log("Deleting order with ID:", orderId);
    axios
      .delete(`http://localhost:5293/Order/delete?id=${orderId}`)
      .then((response) => {
        console.log("Order deleted successfully");

        axios
          .get(`http://localhost:5293/Product/${productId}`)
          .then((response) => {
            const product = response.data;
            const updatedProduct = {
              ...product,
              productStock: product.productStock + quantity
            };

            axios
              .put(`http://localhost:5293/Product/edit`, updatedProduct)
              .then((response) => {
                console.log("Product stock updated successfully");
                closeModal();
              })
              .catch((error) => {
                console.error("Error updating product stock:", error);
              });
          })
          .catch((error) => {
            console.error("Error fetching product details:", error);
          });
      })
      .catch((error) => {
        console.error("Error deleting order:", error);
      });
  };

  return (
    <Modal show={true} onHide={closeModal}>
      <Modal.Header closeButton>
        <Modal.Title>Confirm Delete</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        Are you sure you want to delete this order?
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={closeModal}>Cancel</Button>
        <Button variant="danger" onClick={handleDeleteOrder}>Delete</Button>
      </Modal.Footer>
    </Modal>
  );
};

export default DeleteOrderConfirmation;
